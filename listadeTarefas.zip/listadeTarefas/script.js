var tarefas = []

document.addEventListener("keypress", function(e) {
    if(e.key === 'Enter') {
    
        var btn = document.querySelector("#botao_tarefa");
      
      inserir_tarefa();
    
    }
  });

function limpar_entrada_tarefa() {
    document.getElementById("txt_tarefa").value = ""
}
function gerarid(){
    return Math.floor(Math.random() * 3000)
}

function inserir_tarefa() {
    var texto_tarefa = document.getElementById("txt_tarefa").value

    tarefas.push(texto_tarefa)

    var no_texto_tarefa = document.createTextNode(texto_tarefa)
    var li = document.createElement("li")
    li.setAttribute("id", gerarid())

    var botao = document.createElement("input")
    botao.setAttribute("id", `botao_${tarefas.length}`)
    botao.setAttribute("type", 'button')
    botao.setAttribute("value", 'Concluir')
    botao.setAttribute("onclick", 'concluir('+li.id+')')

    var botaoe = document.createElement("input")
    botaoe.setAttribute("id", `botaoe_${tarefas.length}`)
    botaoe.setAttribute("type", 'button')
    botaoe.setAttribute("value", 'Excluir')
    botaoe.setAttribute("onclick", 'excluir('+li.id+')')

    
    li.appendChild(no_texto_tarefa)
    li.appendChild(botao)
    li.appendChild(botaoe)
    var ul = document.getElementById("lista_tarefas")
    ul.appendChild(li)
    limpar_entrada_tarefa()
}

function concluir(x) { 

    var y = document.getElementById(''+x+ '')
    y.style.background = "blue"
    Lista(x)
}

function excluir(x) {
     
    var comfirmacao = window.confirm("Tem certeza que deseja excluir?")
    if (comfirmacao){
        let li = document.getElementById(''+x+ '')
        if(li){
            lista_tarefas = document.getElementById("lista_tarefas")
            lista_tarefas.removeChild(li)
        }
    }
}

function Lista(x){
    var container = document.getElementById("container");
container.innerHTML = [
  '<table>',
  '<thead>',
  '<tr>',
  '<th>id</th>',
  '<th>col1</th>',
  '<th>col2</th>',
  '<th>col3</th>',
  '</tr>',
  '</thead>',
  '<tbody>',
  '<tr>',
  '<td>1</td>',
  '<td>data</td>',
  '<td>data</td>',
  '<td>data</td>',
  '</tr>',
  '<tr>',
  '<td>2</td>',
  '<td>data</td>',
  '<td>data</td>',
  '<td>data</td>',
  '</tr>',
  '<tr>',
  '<td>3</td>',
  '<td>data</td>',
  '<td>data</td>',
  '<td>data</td>',
  '</tr>',
  '</tbody>',
  '</table>'
].join("\n");
   
}